"""Automation services."""
