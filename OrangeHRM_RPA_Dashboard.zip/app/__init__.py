"""OrangeHRM dashboard application."""
